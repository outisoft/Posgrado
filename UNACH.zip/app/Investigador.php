<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Investigador extends Model
{
    protected $table = 'documents'; //redirigir a otra tabla en la base de datos
}
