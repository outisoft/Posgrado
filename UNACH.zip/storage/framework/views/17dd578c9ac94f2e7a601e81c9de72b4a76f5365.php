<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v4.1.1">
    <title>UNACH - Login</title>
    <link href="<?php echo e(asset('icons/unach.ico')); ?>" rel="shortcut icon" type="image/vnd.microsoft.icon" />

    <link rel="canonical" href="https://getbootstrap.com/docs/4.5/examples/sign-in/">

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">


    <!-- Custom styles for this template -->
    <link href="css/sigin.css" rel="stylesheet">
  </head>
  <body class="text-center">
    <form class="form-signin" form method="POST" action="<?php echo e(route('login')); ?>">
      <?php echo csrf_field(); ?>
      <img class="mb-4" src="icons/unach.ico" alt="" width="210" height="210">
      <h1 class="h3 mb-3 font-weight-normal"><?php echo e(__('Iniciar Sesion')); ?></h1>

        <div class="form-group row">
          <label for="Email" class="sr-only"><?php echo e(__('Correo Electronico')); ?></label>
          <input id="email" type="email" placeholder="Correo Electronico" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

          <div class="col-md-6">
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="form-group row">
          <label for="Password" class="sr-only"><?php echo e(__('Contraseña')); ?></label>
          <input id="password" type="password" placeholder="Contraseña" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password">

          <div class="col-md-6">


              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="invalid-feedback" role="alert">
                      <strong><?php echo e($message); ?></strong>
                  </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <!--div class="checkbox mb-3">
          <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

          <label class="form-check-label" for="remember">
              <?php echo e(__('Remember Me')); ?>

          </label>
        </div-->

        <button type="submit" class="btn btn-lg btn-primary btn-block">
            <?php echo e(__('Iniciar Sesion')); ?>

        </button>
        <?php if(Route::has('password.request')): ?>
            <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                <?php echo e(__('¿Olvidaste tu contraseña?')); ?>

            </a>
        <?php endif; ?>

        <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
            <?php echo e(__('Crear una cuenta')); ?>

        </a>
        <p class="mt-5 mb-3 text-muted">&copy; 2020</p>
    </form>
  </body>
</html>
<?php /**PATH C:\UNACH\UNACH\resources\views/auth/login.blade.php ENDPATH**/ ?>