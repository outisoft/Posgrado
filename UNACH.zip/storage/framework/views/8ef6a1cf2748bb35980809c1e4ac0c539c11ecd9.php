
<?php $__env->startSection('content'); ?>
<div class="container">
<main class="py-4">

  <!-- Begin Page Content -->
  <div class="container-fluid">
    <h1 class="h3 mb-2 text-gray-800">Documentos Aprobados</h1>
    <div class="card shadow mb-4">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
              </tr>
            </tfoot>
            <tbody>
              <?php if(Auth::user()->rol == 'DEFOINVE'): ?>
              <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $validar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($documento->id == $val->id_document && $val->val_defoinve == 1): ?>
                <tr>
                  <td><?php echo e($documento->name); ?></td>
                  <td><?php echo e($documento->created_at->day); ?>-<?php echo e($documento->created_at->month); ?>-<?php echo e($documento->created_at->year); ?> </td>
                  <td><a class="btn btn-info" href="<?php echo e(route('defoinve.show', $documento->id)); ?>">Ver</a></td>
                </tr>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php elseif(Auth::user()->rol == 'DGIP'): ?>
             <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php $__currentLoopData = $validar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($documento->id == $val->id_document && $val->val_dgip == 1): ?>
               <tr>
                 <td><?php echo e($documento->name); ?></td>
                 <td><?php echo e($documento->created_at->day); ?>-<?php echo e($documento->created_at->month); ?>-<?php echo e($documento->created_at->year); ?> </td>
                 <td><a class="btn btn-info" href="<?php echo e(route('dgip.show', $documento->id)); ?>">Ver</a></td>
               </tr>
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             <?php elseif(Auth::user()->rol == 'DI'): ?>
             <?php $__currentLoopData = $doc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php $__currentLoopData = $validar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php if($documento->id == $val->id_document && $val->val_di == 1): ?>
              <tr>
               <td><?php echo e($documento->name); ?></td>
               <td><?php echo e($documento->created_at->day); ?>-<?php echo e($documento->created_at->month); ?>-<?php echo e($documento->created_at->year); ?> </td>
               <td><a class="btn btn-info" href="<?php echo e(route('di.show', $documento->id)); ?>">Ver</a></td>
              </tr>
             <?php endif; ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             <?php endif; ?>

           </tbody>
         </table>
         <?php echo e($doc->links()); ?>

       </div>
     </div>
   </div>


 </div>
</main>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/defoinve/aprobados.blade.php ENDPATH**/ ?>