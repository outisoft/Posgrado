<?php if(session('status_success')): ?>
 <div class="alert alert-success" role="alert">
   <div class="container">
     <div class="d-flex">
       <div class="alert-icon">
         <i class="ion-ios-checkmark-circle"></i>
       </div>
       <p class="mb-0 ml-2"><b>Todo bien! </b><?php echo e(session('status_success')); ?></p>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
         <span aria-hidden="true"><i class="ion-ios-close"></i></span>
       </button>
     </div>
   </div>
 </div>
<?php endif; ?>

<?php if($errors->any()): ?>
 <div class="alert alert-danger" role="alert">
     <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </ul>
 </div>

<?php endif; ?>
<?php /**PATH C:\UNACH\UNACH\resources\views/custom/message.blade.php ENDPATH**/ ?>