

<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row justify-content-center">
    <section id="portfolio" class="portfolio">
      <div class="container" data-aos="fade-up">
        <div class="section-title">
          <h2>Solicitudes de Carta de Postulación</h2>
        </div>
        <div class="row portfolio-container" data-aos="fade-up" data-aos-delay="200">

        <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-lg-3 col-md-6 portfolio-item filter-app">
            <div class="portfolio-img"><img src="<?php echo e(asset('img/pdf.png')); ?>" class="img-fluid" alt=""></div>
            <div class="portfolio-info">
              <h4>Proyecto <?php echo e($documentos->id); ?></h4>
              <p><?php echo e($documentos->sender_id); ?></p>
              <a href="<?php echo e(route('coordinador.show',$documentos->id)); ?>" class="details-link" title="More Details"><i class="bx bx-bullseye"></i></a>
            </div>
          </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
      </div>
    </section>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/coordinador/index.blade.php ENDPATH**/ ?>