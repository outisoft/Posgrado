
<?php $__env->startSection('content'); ?>

<!-- ================ contact section start ================= -->
<div class="container">
  <main class="py-4">
<section class="section-margin">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <h2 class="contact-title">Denegar Solicitud</h2>
      </div>
      <div class="col-lg-8 mb-4 mb-lg-0">
          <form action="<?php echo e(route('documento.update', $defoinve->id)); ?>" method="POST">
           <?php echo csrf_field(); ?>
           <?php echo method_field('PUT'); ?>
          <div class="row">
            <div class="col-12">
              <div class="form-group">
                  <textarea class="form-control w-100" name="descripcion" id="descripcion" cols="30" rows="9" placeholder="Indica el Motivo por el cual se esta denegado la solicitud"></textarea>
              </div>
            </div>
          </div>
          <div class="form-group mt-lg-3">
            <button type="submit" class="btn btn-lg btn-primary btn-block">Enviar</button>
          </div>
        </form>
      </div>
      <div class="col-lg-4">
        <div class="media contact-info">
          <span class="contact-info__icon"><i class="ti-home"></i></span>
          <div class="media-body">
            <h3><?php echo e($defoinve->name); ?></h3>
          </div>
        </div>
        <div class="media contact-info">
          <span class="contact-info__icon"><i class="ti-tablet"></i></span>
          <div class="media-body">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id == $defoinve->sender_id): ?>
            <h3><a href="#"><?php echo e($user->name); ?></a></h3>
            <p><?php echo e($defoinve->created_at->year); ?>-<?php echo e($defoinve->created_at->month); ?>-<?php echo e($defoinve->created_at->day); ?></p>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </div>
        </div>
        <div class="media contact-info">
          <span class="contact-info__icon"><i class="ti-email"></i></span>
          <div class="media-body">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->id == $defoinve->sender_id): ?>
            <h3><a href="mailto:<?php echo e($user->email); ?>"><?php echo e($user->email); ?></a></h3>
            <p>Send us your query anytime!</p>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
</div>
<!-- ================ contact section end ================= -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/defoinve/denegar.blade.php ENDPATH**/ ?>