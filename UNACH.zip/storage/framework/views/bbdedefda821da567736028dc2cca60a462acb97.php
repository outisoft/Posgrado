
<?php $__env->startSection('content'); ?>

<div class="container">
  <!--main class="py-4"-->
<!-- ======= Services Section ======= -->
<section id="services" class="services row justify-content-center">
  <div class="container" data-aos="fade-up">

    <div class="section-title">
      <h2><?php echo e(Auth::user()->name); ?></h2>
    </div>
    <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="row">
     <div class="col-xl-3 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
        <div class="icon-box">
          <div class="icon"><i class="bx bxs-add-to-queue"></i></div>
          <h4><a href="<?php echo e(route('investigador.create')); ?>">Nueva Solicitud</a></h4>
          <p>Realizara una nueva solicitud de carta de postulacion</p>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
        <div class="icon-box">
          <div class="icon"><i class="bx bx-calendar"></i></div>
          <h4><a href="<?php echo e(route('investigador.progreso')); ?>">Progreso</a></h4>
          <p>Puede ver el progreso de aceptacion de su solicitud</p>
        </div>
      </div>

      <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="300">
        <div class="icon-box">
          <div class="icon"><i class="bx bx-history"></i></div>
          <h4><a href="<?php echo e(route('historial')); ?>">Historial</a></h4>
          <p>Puede ver su historial de solicitudes de proyectos anteriormente</p>
        </div>
      </div>

     <div class="col-xl-3 col-md-6 d-flex align-items-stretch mt-4 mt-xl-0" data-aos="zoom-in" data-aos-delay="400">
        <div class="icon-box">
          <div class="icon"><i class="bx bxs-download"></i></div>
          <h4><a href="<?php echo e(route('documents')); ?>">Descarga de documentos</a></h4>
          <p>Podra descargar el documento oficial para solicitar una carta postulacion</p>
        </div>
      </div>
    </div>
  </div>
</section><!-- End Services Section -->
<!--/main-->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/investigador/index.blade.php ENDPATH**/ ?>