
<?php $__env->startSection('content'); ?>

<div class="container">
  <main class="py-4">
  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <h6 class="m-0 font-weight-bold text-primary">Documento</h6>
    </div>
    <div class="card-body">

       <form action="<?php echo e(route('di.update', $di->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th><?php echo e($di->name); ?></th>
            </tr>
          </thead>
          <tbody>
            <td>
              <iframe src="<?php echo e(Storage::url($di->documento)); ?>" width="1042" height="1222" style="border: none;">
              </iframe>
            </td>
          </tbody>
        </table>
        <div class="row py-3">
          <div class="col-md-4 mb-2">
            <!--button type="button" class="btn btn-success btn-lg btn-block">Validar</button-->
            <input class="btn btn-success btn-lg btn-block" type="submit" value="Validar">
          </div>

          <div class="my-2"></div>
          <hr>
          <div class="col-md-4 mb-2">
            <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($di->id == $doc->id): ?>
              <a class="btn btn-danger btn-lg btn-block" href="<?php echo e(route('denegar', $doc->id)); ?>">Denegar</a>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
            <div class="my-2"></div>
              <hr>
          </div>
      </div>
    </form>
    </div>
  </div>
  </main>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/di/view.blade.php ENDPATH**/ ?>