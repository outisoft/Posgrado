
<?php $__env->startSection('content'); ?>

<div class="container">
  <main class="py-4">
    <div class="container marketing">


        <div class="text-center mb-4 justify-content-center">

          <img class="bd-placeholder-img rounded-circle" src="<?php echo e(Storage::url($user->avatar)); ?>" alt="" width="160" height="160" focusable="false" role="img" aria-label="Placeholder: 140x140">

          <h2><?php echo e($user->name); ?></h2>
          <p>Correo: <?php echo e($user->email); ?></p>
          <p>Adscripcion: <?php echo e($user->adscripcion); ?></p>
          <p>Role: <?php echo e($user->rol); ?></p>
          <p><a class="btn btn-secondary" href="<?php echo e(route('perfil.edit', Auth::user()->id )); ?>" role="button">Editar &raquo;</a></p>

        </div><!-- /.col-lg-4 -->

      </div>

  </main>
</div>

<hr class="featurette-divider">


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/perfil/index.blade.php ENDPATH**/ ?>