

<?php $__env->startSection('content'); ?>
<div class="container">
  <main class="py-4">

  <!-- Begin Page Content -->
  <div class="container-fluid">
    <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Documentos</h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
                <th>Descargar</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
                <th>Descargar</th>
              </tr>
            </tfoot>
            <tbody>
              <?php $__currentLoopData = $validacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($documentos->id == $val->id_document && $val->val_defoinve == 0): ?>
              <?php if($documentos->descripcion == null): ?>

              <tr>
                <td><?php echo e($documentos->name); ?></td>
                <td><?php echo e($documentos->created_at->day); ?>-<?php echo e($documentos->created_at->month); ?>-<?php echo e($documentos->created_at->year); ?></td>
                <td>
                  <a class="btn btn-info" href="<?php echo e(route('defoinve.show', $documentos->id)); ?>">Ver</a>
                </td>
                <td><a target="_blank" href="#"><i class="bx bxs-download"></i></a></td>
              </tr>

              <?php endif; ?>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($documento->links()); ?>

        </div>
      </div>
    </div>

  </div>
  <!-- /.container-fluid -->

  </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/defoinve/index.blade.php ENDPATH**/ ?>