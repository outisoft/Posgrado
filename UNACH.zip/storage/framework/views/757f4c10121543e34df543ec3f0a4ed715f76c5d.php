
<?php $__env->startSection('content'); ?>


<section class="ftco-section">
  <div class="container">
    <div class="row">
      <div class="col-md-6">
        <h2 class="heading-section mb-4">Progreso de Solicitud <br>
          <!--div class="form-group row">
            <div class="col-md-9">
  						<h2 class="heading-section">
  							<small>Seleccione su sulicitud</small>
  						</h2>
  					</div>
              <label for="rol" class="sr-only"><?php echo e(__('Solicitudes')); ?></label>

                <select id="rol" class="btn btn-secondary dropdown-toggle form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Rol" type="rol"  name="rol" value="<?php echo e(old('rol')); ?>">
                  <?php $__currentLoopData = $document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Auth::user()->id == $documentos->sender_id): ?>
                      <option value='<?php echo e($documentos->id); ?>'><?php echo e($documentos->name); ?></option>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <div class="col-md-6">
                <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
          </div-->
          <label for="rol" class="sr-only"><?php echo e(__('Solicitudes')); ?></label>

          <!--div class="progress mb-4" style="height: 30px; width: 1100px;">
            <div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 75%;">
              <span>75% Complete</span>
            </div>
          </div-->
          <?php $__currentLoopData = $document; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if(Auth::user()->id == $doc->sender_id): ?>
          <?php $__currentLoopData = $validation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($doc->id == $validar->id_document): ?>
            <?php if($validar->val_defoinve == 1): ?>
             <?php if($validar->val_di == 1): ?>
              <?php if($validar->val_dgip == 1): ?>
              <?php echo e($doc->name); ?>

              <div class="progress mb-4" style="height: 30px; width: 1100px;">
              <div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 75%;">
                <span>75% Complete</span>
              </div>
              </div>
              <?php else: ?>
              <?php echo e($doc->name); ?>

              <div class="progress mb-4" style="height: 30px; width: 1100px;">
              <div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 50%;">
                <span>50% Complete</span>
              </div>
              </div>
              <?php endif; ?>
             <?php else: ?>
             <?php echo e($doc->name); ?>

             <div class="progress mb-4" style="height: 30px; width: 1100px;">
             <div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 25%;">
               <span>25% Complete</span>
             </div>
             </div>
            <?php endif; ?>
            <?php else: ?>
            <?php echo e($doc->name); ?>

            <div class="progress mb-4" style="height: 30px; width: 1100px;">
            <div class="progress-bar progress-bar-striped" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 0%;">
              <span>0% Complete</span>
            </div>
            </div>
            <?php endif; ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <small></small>
        </h2>
      </div>
    </div>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/investigador/progreso.blade.php ENDPATH**/ ?>