

<?php $__env->startSection('content'); ?>
<div class="container">
  <main class="py-4">

  <!-- Begin Page Content -->
  <div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">Documentos</h1>
    <!--p class="mb-4">Documentos oficiales para realizar la solicitud de elaboracion de cartas de postulacion instuticional a profesores-investigadores de la <a target="_blank" href="https://unach.com">universidad autonoma de Chiapas</a>.</p-->

    <!-- DataTales Example -->
    <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card shadow mb-4">
      <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Documentos</h6>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
              </tr>
            </thead>
            <tfoot>
              <tr>
                <th>Nombre</th>
                <th>Fecha</th>
                <th>Ver</th>
              </tr>
            </tfoot>
            <tbody>
              <!--The Current User Can Update The Post -->
              <?php $__currentLoopData = $validacion; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validations): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($validations->val_defoinve == 1): ?>
                <?php $__currentLoopData = $documento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($documentos->descripcion == null): ?>
                <?php if($validations->val_di == 0): ?>
                 <?php if($documentos->id == $validations->id_document): ?>
                    <tr>
                      <td><?php echo e($documentos->name); ?></td>
                      <td><?php echo e($documentos->created_at->day); ?>-<?php echo e($documentos->created_at->month); ?>-<?php echo e($documentos->created_at->year); ?> </td>
                      <td><a class="btn btn-info" href="<?php echo e(route('di.show', $documentos->id)); ?>">Ver</a></td>
                    </tr>
                    <?php endif; ?>
                    <?php endif; ?>
                    <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($documento->links()); ?>

        </div>
      </div>
    </div>

  </div>
  <!-- /.container-fluid -->

  </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/di/index.blade.php ENDPATH**/ ?>