
<?php $__env->startSection('content'); ?>
<div class="container">
  <main class="py-4">

<!-- Brand Buttons -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary">Subir Solicitud</h6>
    </div>
    <div class="card-body">
      <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="form-group">
        <label for="sender_id">De: <?php echo e(Auth::user()->name); ?></label>
      </div>
      <form method="POST" action="<?php echo e(route('investigador.store')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>


        <!-- Receptor (Start) -->
        <div class="panel-body">
          <div class="form-group">Para:
            <select name="recipient_id" class="form-control">
              <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($user->rol == "DEFOINVE" || $user->rol == "Defoinve"): ?>

                  <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
              <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
          </div>
        </div>
        <!-- Receptor (Start)-->

        <!-- Name (Start)-->
        <div class="panel-body">
          <div class="form-group">Nombre de la solicitud:
            <input name="name" type="text" class="form-control form-control-user" value="<?php echo e(old('name')); ?>" placeholder="Nombre de la solicitud...">
          </div>
        </div>
        <!-- Name (Finish) -->

        <!-- Documento (Start)-->
        <div class="form-group">
          <label for="documento">Seleccionar Solicitud(.pdf)</label>
          <input name="documento" type="file" value="<?php echo e(old('documento')); ?>"></input>
        </div>
        <!-- Documento (Finish)-->
        <!-- Anexos (Start)-->
        <div class="form-group">
          <label for="anexo">Seleccionar Anexos(.pdf)</label>
          <input name="anexo" type="file" value="<?php echo e(old('anexo')); ?>"></input>
        </div>
        <!-- Anexos (Finish)-->

        <button class="btn btn-primary">Enviar Solicitud</button>
      </form>
    </div>
  </div>
</main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/investigador/create.blade.php ENDPATH**/ ?>