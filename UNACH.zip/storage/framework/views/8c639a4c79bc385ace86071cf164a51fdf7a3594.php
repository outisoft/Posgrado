
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row justify-content-center">
    <main class="py-4">
      <div class="container-fluid">
        <div class="card shadow mb-4">
          <div class="card-header py-3"><h2>Lista de solicitudes de <?php echo e($user->name); ?></h2></div>
            <div class="card-body">  <br><br>
              <?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                          <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nombre</th>
                            <th scope="col">Estado</th>
                            <th scope="col">Fecha</th>
                            <th scope="col">Ver</th>
                            <th colspan="3">Descargar</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if($user->id == $doc->sender_id): ?>
                            <tr>
                              <th scope="row"><?php echo e($doc->id); ?></th>
                              <td><?php echo e($doc->name); ?></td>
                              <td>
                                <?php $__currentLoopData = $validation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $validar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($doc->id == $validar->id_document): ?>
                                  <?php if($validar->val_defoinve == 1): ?>
                                   <?php if($validar->val_di == 1): ?>
                                    <?php if($validar->val_dgip == 1): ?>
                                     <span class="badge px-3 badge-success">DGIP Validado</span>
                                    <?php else: ?>
                                      <span class="badge px-3 badge-info">DI Validado</span>
                                    <?php endif; ?>
                                   <?php else: ?>
                                    <span class="badge px-3 badge-warning">Defoinve Validado</span>
                                  <?php endif; ?>
                                  <?php else: ?>
                                    <span class="badge px-3 badge-danger">Sin Validar</span>
                                  <?php endif; ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </td>
                              <td><?php echo e($doc->created_at->day); ?>-<?php echo e($doc->created_at->month); ?>-<?php echo e($doc->created_at->year); ?></td>
                              <td><a class="btn btn-info" href="<?php echo e(route('investigador.show', $doc->id)); ?>">Ver</a></td>
                              <td><a target="_blank" href="#"><i class="bx bxs-download"></i></a></td>
                            </tr>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <?php echo e($documents->links()); ?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/users/investigador/historial.blade.php ENDPATH**/ ?>