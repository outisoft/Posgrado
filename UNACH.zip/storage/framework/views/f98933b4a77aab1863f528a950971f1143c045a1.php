
<?php $__env->startSection('content'); ?>

<div class="card-body">
<?php echo $__env->make('custom.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <form action="<?php echo e(route('perfil.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
   <?php echo method_field('PUT'); ?>
   <div class="container">
     <main class="py-4">
       <div class="container marketing">
         <div class="text-center mb-4 justify-content-center">
           <img class="bd-placeholder-img rounded-circle" src="<?php echo e(Storage::url($user->avatar)); ?>" alt="" width="160" height="160" focusable="false" role="img" aria-label="Placeholder: 140x140">

           <div class="form-group">
             <input name="avatar" type="file"></input>
           </div>

           <h2><label for="name"> Name:
             <input class="form-control" type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>">
           <p>

             <label for="email"> Correo:
             <input class="form-control" type="text" name="email" value="<?php echo e(old('email', $user->email)); ?>">
            </p>
            <p>Role: <?php echo e($user->rol); ?></p>
            <p>
              <input class="btn btn-primary" type="submit" value="Guardar &raquo;">
            </p>
           </div><!-- /.col-lg-4 -->
         </div>
       </main>
     </div>
   </form>
  </div>
<hr class="featurette-divider">

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\UNACH\UNACH\resources\views/perfil/edit.blade.php ENDPATH**/ ?>